// 1713075
// 2018-3-17
// Assignment 6

#include "Game.h"

using namespace std;
int main() {
  Game::initialize();
  return 0;
}