#!/bin/bash

g++ -std=c++11 -Wall -g -Og chess.cpp Board.cpp Square.cpp Piece.cpp RestrictedPiece.cpp Rook.cpp King.cpp Player.cpp Game.cpp Pawn.cpp Queen.cpp Knight. cpp Bishop.cpp && ./a.out

