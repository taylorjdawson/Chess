/**
 * Project Chess
 * @author Taylor J. Dawson
 */


#include <iostream>
#include "Pawn.h"
#include "Board.h"
#define PIECE_SYMBOL ("P")

/**
 * Pawn implementation
 */


/**
 * @return int
 */
int Pawn::getValue() {
  return 0;
}

/**
 * @param location
 * @return boolean
 */
bool Pawn::canMoveTo(Square &location) {
  bool canMove = false;

  int rank = 0; //TODO: Change name

  /*If pawn is Black it can only move rank - 1*/
  /*If pawn is White it can only move rank + 1*/
  rank = (this->getColor() == "B") ? 1 : -1; //TODO: Change color to enumeration
  /* Check that the square is in the next rank up/down(white/black) and that it
   * is within +- 1 of the file */
  std::cout << "Rank From: " << getLocation()->getRank();
  std::cout << "File From: " << getLocation()->getFile();
  std::cout << "Rank To: " << location.getRank();
  std::cout << "File To: " << location.getFile();


  std::cout << (location.getRank() == this->getLocation()->getRank() + -1) << endl;
  std::cout << (location.getFile() >= this->getLocation()->getFile() - 1) << endl;
  std::cout << (location.getFile() <= this->getLocation()->getFile() + 1) << endl;
//  std:cout << << endl;
  if (( ( location.getRank() == this->getLocation()->getRank() - rank || !hasMoved() && location.getRank()
      == this->getLocation()->getRank() + rank + rank )  &&
      (location.getFile() >= this->getLocation()->getFile() - 1)) &&
      (location.getFile() <= this->getLocation()->getFile() + 1)) {
    std::cout << "got here!" << endl;
    /* Check to see if the diagonals contain occupants of a different color*/
    Square squareDiagLeft =
        Board::getInstance()->getSquareAt(this->getLocation()->getRank() + rank,
                                          location.getFile() - 1);
    Square squareDiagRight =
        Board::getInstance()->getSquareAt(this->getLocation()->getRank() + rank,
                                          location.getFile() + 1);
    if ((squareDiagLeft == location
        && squareDiagLeft.isOccupied()
        && squareDiagLeft.getOccupant()->getColor() != this->getColor())
        || (squareDiagRight == location
            && squareDiagRight.isOccupied()
            && squareDiagRight.getOccupant()->getColor() != this->getColor())) {
      canMove = true;
    }
  }
  return canMove;
}

string Pawn::getPieceSymbol() {
  //TODO: Change to enum later
  return this->getColor() == "B" ? "♟" : "♙";
}
Pawn::Pawn(const string &color, Square *location) : RestrictedPiece(color,
                                                                    location) {}


