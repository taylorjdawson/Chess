// 1713075
// 2018-4-8
// Assignment 7
/* W.I.P. -- The poop hit the fan */

#include <limits>
#include <regex>
#include "Game.h"

using namespace std;
int main() {
  Game::initialize();

  Player* player = Game::getNextPlayer();
  bool done = true;

  while(done)
  {
    while(!player->makeMove()){}
    player = Game::getNextPlayer();
  }

//  std::set<int> myset;
//  cout << *(myset.insert(10).first) << endl;

//  cout << (int) "♜";

//  char str[] = "\u2654\n";
//  setlocale(LC_ALL, "");
//  printf("%lc\n", 0x2654 + 6);
/*  for (i = 0; i < 0xffff; i++) {
    printf("%x - %lc\n", i, i);
  }*/
  return 0;
}